%%%%%%%%%%%% Mission Planner %%%%%%%%%%%%%%%%%%

Path.onOff = 0;             % 0 = path following only, 1 = path manager 

Path.waypoints = [0 0;
                500 500;
                500 0;
                0 500;
                0 0;
                500 500;
                500 0];            
